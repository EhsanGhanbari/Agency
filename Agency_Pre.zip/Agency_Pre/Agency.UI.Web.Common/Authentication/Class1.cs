﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agency.UI.Web.Common.Authentication
{
    /// <summary>
    /// http://dotnet.dzone.com/articles/api-key-user-aspnet-web-api
    /// http://www.codeproject.com/Articles/630986/Cross-Platform-Authentication-With-ASP-NET-Web-API1
    /// </summary>
    class Class1
    {
    }
}
